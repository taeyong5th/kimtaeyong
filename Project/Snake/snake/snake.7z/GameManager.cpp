#include "GameManager.h"

GameManager::GameManager()
{
	setConsoleSize();
	m_iWidth = MAP_SIZE_WIDTH;
	m_iHeight = MAP_SIZE_HEIGHT;
	m_foods = NULL;
}

GameManager::~GameManager()
{

}

void GameManager::init()
{
	//m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight, true);
	int positionY = m_iHeight * 0.2;
	m_MapDraw.DrawMidText("                 ", m_iWidth, positionY);
	m_MapDraw.DrawMidText("                 ", m_iWidth, positionY + 2);
	m_MapDraw.DrawMidText("                 ", m_iWidth, positionY + 4);
	m_MapDraw.DrawMidText("                 ", m_iWidth, positionY + 6);

	m_Snake.init(m_iWidth / 2, m_iHeight / 2);
	m_Snake.draw();

}

void GameManager::start()
{
	int positionY = m_iHeight * 0.2;
	m_MapDraw.BoxDraw(0, 0, m_iWidth, m_iHeight);
	m_MapDraw.DrawMidText("�� Snake Game ��", m_iWidth, positionY);
	m_MapDraw.DrawMidText("1. ���� ����", m_iWidth, positionY + 2);
	m_MapDraw.DrawMidText("2. ���� ����", m_iWidth, positionY + 4);
	m_MapDraw.DrawMidText("�Է� : ", m_iWidth, positionY + 6);
	m_MapDraw.gotoxy(m_iWidth + 6, positionY + 6);

	while (true)
	{
		int menuSelect;
		cin >> menuSelect;
		switch (menuSelect)
		{
		case MAIN_MENU_PLAY:
			init();
			return play();
		case MAIN_MENU_EXIT:
			return;
		default:
			return start();
		}
	}
}

void GameManager::play()
{
	clock_t foodClock, snakeClock;
	clock_t curClock;
	snakeClock = foodClock = clock();
	
	while (true)
	{
		if (kbhit()) {
			char key = getch();
			switch (key)
			{
			case KEY_LEFT: // left
				m_Snake.setDirection(DIRECTION_LEFT);
				break;
			case KEY_RIGHT: // right
				m_Snake.setDirection(DIRECTION_RIGHT);
				break;
			case KEY_UP: // up
				m_Snake.setDirection(DIRECTION_UP);
				break;
			case KEY_DOWN: // down
				m_Snake.setDirection(DIRECTION_DOWN);
				break;
			default:
				break;
			}
		}
		
		curClock = clock();
		if (curClock - foodClock > 1000)
		{
			makeFood();
			foodClock = clock();
		}

		if (curClock - snakeClock > 200)
		{
			if (isCollision(m_foods, *(m_Snake.m_head)))
			{
				m_Snake.action(ACTION_EAT);
			}
			else
			{
				m_Snake.action(ACTION_MOVE);
			}
			
			snakeClock = clock();
		}


		srand(time(NULL));				
		int x = rand() % (m_iWidth - 2) + 1;
		int y = rand() % (m_iHeight - 2) + 1;

		//Block *new_food = new Block(BLOCK_STATE_FOOD, x, y);		
		//new_food->draw();
		//delete new_food;

		
	}
}

void GameManager::makeFood()
{
	// ������ �ִ� ������ ������ ����
	if (countFood() == FOOD_MAX)
	{
		return;
	}

	srand(time(NULL));
	int x = rand() % (m_iWidth - 2) + 1;
	int y = rand() % (m_iHeight - 2) + 1;

	Block* newFood = new Block(BLOCK_STATE_FOOD, x, y);
	
	// ���� �ִ� ��ġ�� �浹�Ǹ� ������ �ٽ� ����
	if (m_Snake.isAllCollision(*newFood)) {
		delete newFood;
		//return makeFood();
		return;
	}

	if (m_foods == NULL)
	{
		m_foods = newFood;
	}
	else
	{
		Block* temp = m_foods;
		while (temp->nextBlock != NULL)
		{
			temp = temp->nextBlock;
		}
		temp->nextBlock = newFood;
	}
	newFood->draw();
}

int GameManager::countFood()
{
	int count = 0;
	Block* temp = m_foods;
	while (temp != NULL)
	{
		temp = temp->nextBlock;
		count++;
	}
	
	return count;
}


bool GameManager::isCollision(Block* head, const Block& block)
{
	Block* temp = head;
	while (temp != NULL)
	{
		if (temp->isCollision(block))
			return true;
		temp = temp->nextBlock;
	}
	return false;
}

void GameManager::setConsoleSize(int width, int height)
{
	string command = "mode con cols=" + to_string(width) + " lines=" + to_string(height);
	system(command.c_str());
}
