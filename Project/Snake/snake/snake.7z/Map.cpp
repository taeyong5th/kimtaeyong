#include "Map.h"


Map::Map()
{
}

Map::Map(int x, int y, int width, int height)
{
	m_ix = x;
	m_iy = y;
	m_iWidth = width;
	m_iHeight = height;
	init();
}

Map::~Map()
{
}

void Map::init()
{
	srand(time(NULL));
	
}

void Map::MapDraw()
{
	m_DrawManager.BoxDraw(m_ix, m_iy, m_iWidth, m_iHeight, false);
}

void Map::setSize(int width, int hegith)
{
	m_iWidth = width;
	m_iHeight = hegith;
	init();
}

// �̵������� �������� �˻��Ѵ�.
bool Map::isValidPosition(int x, int y)
{
	if ((x > m_ix / 2) && (x < m_ix / 2 + m_iWidth - 1) && (y > m_iy) && (y < m_iy + m_iHeight - 1))
	//if ((x > m_ix / 2 - 1) && (x < m_ix / 2 + m_iWidth) && (y > m_iy - 1) && (y < m_iy + m_iHeight))
		return true;
	else
		return false;
}
