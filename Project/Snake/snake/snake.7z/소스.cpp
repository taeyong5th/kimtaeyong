#include "Mecro.h"
#include "GameManager.h"


int main()
{	
	GameManager gameManager;
	gameManager.start();

	clock_t start = clock();
	clock_t current = 0;

	while (true)
	{
		current = clock();
		if (current - start > 1000)
		{
			cout << "!" << endl;
			start = clock();
		}
	}
		
	return 0;
}